import * as React from 'react';
import { payloadHash } from '../../content/actionEnvelope';
import { CANONICAL_WORK_ID } from '../../content/workIdentity';
import { browserLocalStorage } from '../../services/draftStorage';
import { useFrontDoor } from '../../context/FrontDoorContext';
import { usePageDocument } from '../pages/PageDocumentContext';
import type { CoreCallResult, ICoreSession, ICoreWorkService } from '../../services/core/coreWorkService';
import { evaluateDecisionPacket } from '../../services/core/coreWorkService';
import { KNOWN_ASSUMED_UNKNOWN, parseResponse, toEmployeeWork } from '../../services/core/coreContract';
import type { IEmployeeWork, IS1, KnownAssumedUnknown } from '../../services/core/coreContract';
import type { IWorkPacketProjection } from '../../services/core/packetProjection';
import { PACKET_PROJECTION_EXTENSION } from '../../services/core/packetProjection';
import { AppNotice } from './kit';

/**
 * Case workspace over either the labelled synthetic engine or a qualified native service.
 * Native recovery and human validation retain server authority; UI role membership grants no backend rights.
 *
 * Wording note: this file is scanned for Tailwind utility names; keep prose free of utility words.
 */
export const SYNTHETIC_CORE_NOTICE: string =
  'Synthetic Binding A workspace: real command keys, validators and polling over a local command list. Not a tenant write, not approval, and not a live model call.';

export function AppCoreWorkspace({ coreWork }: { coreWork: ICoreWorkService }): React.ReactElement {
  const { user, siteUrl } = useFrontDoor();
  return <CoreCaseWorkspace key={`${siteUrl}:${user.email}:${coreWork.mode}`} coreWork={coreWork} />;
}

/** Only an opaque WorkID is kept; neither account names nor business text are storage values. */
export async function coreSelectionKey(session: ICoreSession, mode: ICoreWorkService['mode']): Promise<string | undefined> {
  const scope = await payloadHash({ actorId: session.actorId, tenantScope: session.tenantScope, mode });
  return scope === undefined ? undefined : `ai-coe:selected-work:v1:${scope}`;
}

function CoreCaseWorkspace({ coreWork }: { coreWork: ICoreWorkService }): React.ReactElement {
  const { user, siteUrl } = useFrontDoor();
  const { roles, rolesState } = usePageDocument();
  const mayValidate = rolesState === 'resolved' && roles?.includes('designAuthority') === true;
  const [disposition, setDisposition] = React.useState<'' | 'VALIDATED' | 'REJECTED' | 'NOT_APPLICABLE'>('');
  const [assertion, setAssertion] = React.useState<string>('');
  const [sourceRefs, setSourceRefs] = React.useState<string>('');
  const references = sourceRefs.split(/\r?\n/).map((ref): string => ref.trim()).filter((ref): boolean => ref !== '');
  const session: ICoreSession = React.useMemo((): ICoreSession => ({ actorId: user.email, tenantScope: siteUrl }), [user.email, siteUrl]);
  const selectionKey = React.useMemo(() => coreSelectionKey(session, coreWork.mode), [session, coreWork.mode]);
  const mounted = React.useRef<boolean>(true);
  const [title, setTitle] = React.useState<string>(coreWork.mode === 'synthetic' ? 'Automate a weekly operations pack' : '');
  const [outcome, setOutcome] = React.useState<string>(coreWork.mode === 'synthetic' ? 'A reviewed weekly pack with less copying.' : '');
  const [problem, setProblem] = React.useState<string>(coreWork.mode === 'synthetic' ? 'Hours spent copying numbers between tools.' : '');
  const [sponsor, setSponsor] = React.useState<string>(coreWork.mode === 'synthetic' ? 'Named sponsor (synthetic)' : '');
  const [edited, setEdited] = React.useState<Partial<Record<keyof IS1, true>>>({});
  const editedRef = React.useRef<Partial<Record<keyof IS1, true>>>({});
  const markEdited = (field: keyof IS1): void => { editedRef.current = { ...editedRef.current, [field]: true }; setEdited(editedRef.current); };
  const clearEdited = (): void => { editedRef.current = {}; setEdited({}); };
  const hasEdits: boolean = Object.keys(edited).length > 0;
  const [work, setWork] = React.useState<IEmployeeWork | undefined>(undefined);
  const [items, setItems] = React.useState<IEmployeeWork[] | undefined>(undefined);
  const [packets, setPackets] = React.useState<IWorkPacketProjection[]>([]);
  const [packetId, setPacketId] = React.useState<string>('');
  const [response, setResponse] = React.useState<string>('');
  const [certainty, setCertainty] = React.useState<KnownAssumedUnknown>('UNKNOWN');
  const [packetReasons, setPacketReasons] = React.useState<readonly string[]>([]);
  const selectedPacket = packets.filter((packet): boolean => packet.packetId === packetId)[0];
  const [status, setStatus] = React.useState<string>(coreWork.label);
  const [phase, setPhase] = React.useState<string>('idle');
  const [busy, setBusy] = React.useState<boolean>(coreWork.enabled && coreWork.recoverPending !== undefined);
  const busyRef = React.useRef<boolean>(busy);
  const [recoveryBlocked, setRecoveryBlocked] = React.useState<boolean>(busy);
  const recoveryRef = React.useRef<boolean>(busy);
  const blockForRecovery = React.useCallback((blocked: boolean): void => {
    recoveryRef.current = blocked;
    setRecoveryBlocked(blocked);
  }, []);

  const apply = React.useCallback(
    async (result: CoreCallResult): Promise<void> => {
      if (!mounted.current) { return; }
      blockForRecovery(coreWork.recoverPending !== undefined && (result.kind === 'disabled' || result.observation.phase !== 'completed'));
      if (result.kind === 'disabled') {
        setPhase('error');
        setStatus(result.reasons.join(' '));
        return;
      }
      const observation = result.observation;
      setPhase(observation.phase);
      if (result.kind === 'ok') {
        if (observation.response !== undefined && 'Items' in observation.response) {
          const parsed = parseResponse('ListMyWork', observation.response, coreWork.mode === 'live' ? 'v0.2.0' : 'v0.1.1');
          if (!parsed.valid || parsed.value === undefined || !('Items' in parsed.value)) {
            setItems(undefined);
            setPhase('error');
            setStatus('The saved case list was malformed and was not displayed.');
            return;
          }
          setItems(parsed.value.Items.map(toEmployeeWork));
        }
        if (result.work !== undefined) {
          setWork(result.work);
          if (!editedRef.current.Title) { setTitle(result.work.title); }
          const key = await selectionKey;
          if (!mounted.current) { return; }
          try {
            if (key !== undefined) { browserLocalStorage()?.setItem(key, result.work.workId); }
          } catch { /* A refused reference cache never falls back to business-content storage. */ }
        }
        setStatus(`${observation.phase}: ${result.work?.employeeStatus ?? observation.reason ?? 'completed'}`);
        if (result.packets !== undefined) {
          setPackets(result.packets);
          setPacketReasons([]);
        } else if (result.work !== undefined) {
          const listed = await coreWork.listPackets(session, result.work.workId);
          if (mounted.current) {
            setPackets(listed.packets); setPacketReasons(listed.unboundReasons);
            if (coreWork.recoverPending !== undefined && listed.unboundReasons.length > 0) { blockForRecovery(true); }
          }
        }
        return;
      }
      const message: string = observation.response !== undefined && observation.response.Result !== 'PASS' ? observation.response.Message : observation.reason ?? 'The command did not complete.';
      setStatus(message);
    },
    [coreWork, session, selectionKey, blockForRecovery]
  );

  const recoverAndList = React.useCallback(async (): Promise<void> => {
    if (!coreWork.enabled || coreWork.recoverPending === undefined) { return; }
    const result = await coreWork.recoverPending(session);
    if (!mounted.current) { return; }
    if (result === undefined) { blockForRecovery(false); }
    else { await apply(result); }
    if (!mounted.current || recoveryRef.current) { return; }
    await apply(await coreWork.listMine(session));
  }, [coreWork, session, apply, blockForRecovery]);

  React.useEffect((): (() => void) => {
    mounted.current = true;
    let cancelled = false;
    const restore = async (): Promise<void> => {
      if (!coreWork.enabled) { return; }
      if (coreWork.recoverPending !== undefined) {
        busyRef.current = true; setBusy(true);
        try { await recoverAndList(); }
        catch {
          if (!cancelled) { blockForRecovery(true); setStatus('Recovery could not confirm the original command. Recover the pending result before another request.'); }
        } finally { if (!cancelled) { busyRef.current = false; setBusy(false); } }
        if (cancelled || recoveryRef.current) { return; }
      }
      const key = await selectionKey;
      let reference: string | null | undefined;
      try { reference = key === undefined ? undefined : browserLocalStorage()?.getItem(key); } catch { return; }
      if (cancelled || !coreWork.enabled || typeof reference !== 'string' || !CANONICAL_WORK_ID.test(reference)) { return; }
      busyRef.current = true; setBusy(true);
      setProblem(''); setOutcome(''); setSponsor('');
      try {
        const result = await coreWork.getStatus(session, reference);
        if (!cancelled) { await apply(result); }
      } catch {
        if (!cancelled) { setStatus('The selected case could not be reloaded. Use List my work to try again.'); }
      } finally {
        if (!cancelled) { busyRef.current = false; setBusy(false); }
      }
    };
    void restore();
    return (): void => { cancelled = true; mounted.current = false; };
  }, [selectionKey, coreWork, session, apply, recoverAndList, blockForRecovery]);

  const s1 = React.useCallback((): IS1 => {
    const value: IS1 = {
      Title: title.trim(),
      SourceChannel: 'FRONT_DOOR'
    };
    if (work === undefined || edited.ProblemStatement) { value.ProblemStatement = problem.trim() === '' ? null : problem.trim(); }
    if (work === undefined || edited.DesiredOutcome) { value.DesiredOutcome = outcome.trim() === '' ? null : outcome.trim(); }
    if (work === undefined || edited.Sponsor) { value.Sponsor = sponsor.trim() === '' ? null : sponsor.trim(); }
    if (work === undefined) { value.Requester = user.email; value.DataClassification = 'INTERNAL'; }
    return value;
  }, [title, outcome, problem, sponsor, user.email, work, edited]);

  const run = React.useCallback(
    (work: () => Promise<void>, recovery: boolean = false): void => {
      if (!coreWork.enabled || busyRef.current || (!recovery && recoveryRef.current)) { return; }
      busyRef.current = true;
      setBusy(true);
      work().then(
        (): void => { if (mounted.current) { busyRef.current = false; setBusy(false); } },
        (): void => {
          if (!mounted.current) { return; }
          busyRef.current = false; setBusy(false);
          blockForRecovery(coreWork.recoverPending !== undefined);
          setPhase('error');
          setStatus('CORE could not confirm the result. Recover the pending result before repeating a request.');
        }
      );
    },
    [coreWork, blockForRecovery]
  );

  return (
    <div className="ai-app-panel">
      <AppNotice tone="info">{coreWork.mode === 'synthetic' ? SYNTHETIC_CORE_NOTICE : 'Native CORE: commands and evidence are authorized and recorded by the bound server. A pending result is not confirmation or approval.'}</AppNotice>
      <p className="ai-app-note">{coreWork.label}</p>
      {!coreWork.enabled && (
        <ul className="ai-app-list">
          {coreWork.liveReasons.map((reason: string): React.ReactElement => (
            <li key={reason}>{reason}</li>
          ))}
        </ul>
      )}
      {coreWork.enabled && (
        <React.Fragment>
          <label className="ai-app-field-label" htmlFor="ai-core-title">
            Title
            <input id="ai-core-title" className="ai-app-command-input" disabled={busy} value={title} onChange={(event: React.ChangeEvent<HTMLInputElement>): void => { setTitle(event.target.value); markEdited('Title'); }} />
          </label>
          <label className="ai-app-field-label" htmlFor="ai-core-problem">
            Problem statement
            <input id="ai-core-problem" className="ai-app-command-input" disabled={busy} value={problem} onChange={(event: React.ChangeEvent<HTMLInputElement>): void => { setProblem(event.target.value); markEdited('ProblemStatement'); }} />
          </label>
          <label className="ai-app-field-label" htmlFor="ai-core-outcome">
            Desired outcome
            <input id="ai-core-outcome" className="ai-app-command-input" disabled={busy} value={outcome} onChange={(event: React.ChangeEvent<HTMLInputElement>): void => { setOutcome(event.target.value); markEdited('DesiredOutcome'); }} />
          </label>
          <label className="ai-app-field-label" htmlFor="ai-core-sponsor">
            Sponsor (role, not a default person)
            <input id="ai-core-sponsor" className="ai-app-command-input" disabled={busy} value={sponsor} onChange={(event: React.ChangeEvent<HTMLInputElement>): void => { setSponsor(event.target.value); markEdited('Sponsor'); }} />
          </label>
          {work !== undefined && <p className="ai-app-note">Only fields you edit are saved. An untouched blank field does not clear an existing server value.</p>}
          {coreWork.recoverPending !== undefined && <button type="button" disabled={busy} onClick={(): void => run(recoverAndList, true)}>Recover pending result</button>}
          {recoveryBlocked && <AppNotice>Confirm the original command before another request. Recovery reads the original result; it does not repeat a mutation.</AppNotice>}
          <div className="ai-app-actions">
            <button type="button" className="ai-app-primary" disabled={busy || recoveryBlocked} onClick={(): void => run(async (): Promise<void> => {
              if (work !== undefined && !hasEdits) { setStatus('Edit a clarification field before saving.'); return; }
              const result = await coreWork.createOrResume(session, { s1: s1(), workId: work?.workId, changedFields: work === undefined ? undefined : Object.keys(edited) as (keyof IS1)[] });
              if (result.kind === 'ok') { clearEdited(); }
              await apply(result);
            })}>
              {work === undefined ? 'Create work' : 'Save clarification'}
            </button>
            <button
              type="button"
              className="ai-app-ghost"
              disabled={busy || recoveryBlocked || work === undefined || hasEdits}
              onClick={(): void =>
                run(async (): Promise<void> => {
                  if (work !== undefined) {
                    await apply(await coreWork.getStatus(session, work.workId));
                  }
                })
              }
            >
              Refresh status
            </button>
            {work !== undefined && hasEdits && <button type="button" disabled={busy || recoveryBlocked} onClick={(): void => { clearEdited(); setTitle(work.title); setProblem(''); setOutcome(''); setSponsor(''); }}>Discard unsaved clarification</button>}
            <button type="button" className="ai-app-ghost" disabled={busy || recoveryBlocked} onClick={(): void => run(async (): Promise<void> => apply(await coreWork.listMine(session)))}>
              List my work
            </button>

            <button
              type="button"
              className="ai-app-ghost"
              disabled={busy || recoveryBlocked || work === undefined}
              onClick={(): void =>
                run(async (): Promise<void> => {
                  if (work !== undefined) {
                    await apply(await evaluateDecisionPacket(coreWork, session, work.workId));
                  }
                })
              }
            >
              Ask for a decision packet
            </button>
          </div>
        </React.Fragment>
      )}
      <p className="ai-app-note" data-core-phase={phase}>{`Command: ${phase}. ${status}`}</p>
      {items !== undefined && <section aria-label="My saved cases">
        <h3 className="ai-app-subheading">My saved cases</h3>
        {items.length === 0 ? <p>No saved cases were returned.</p> : <ul className="ai-app-list">
          {items.map((item: IEmployeeWork): React.ReactElement => <li key={item.workId}>
            <button type="button" disabled={busy || recoveryBlocked || hasEdits} aria-pressed={work?.workId === item.workId} onClick={(): void => run(async (): Promise<void> => {
              clearEdited();
              setWork(undefined);
              setPackets([]);
              setPacketId(''); setResponse(''); setCertainty('UNKNOWN');
              setTitle(item.title);
              setProblem('');
              setOutcome('');
              setSponsor('');
              await apply(await coreWork.getStatus(session, item.workId));
            })}>{`${item.title} — ${item.workId} — ${item.employeeStatus}`}</button>
          </li>)}
        </ul>}
      </section>}
      {work !== undefined && (
        <dl className="ai-app-contract">
          <dt>Work ID</dt>
          <dd>{work.workId}</dd>
          <dt>State</dt>
          <dd>{work.state}</dd>
          <dt>Employee status</dt>
          <dd>{work.employeeStatus}</dd>
          <dt>Version</dt>
          <dd>{String(work.version)}</dd>
          <dt>Next action</dt>
          <dd>{work.nextAction ?? 'None'}</dd>
        </dl>
      )}
      {packetReasons.length > 0 && <AppNotice>{packetReasons.join(' ')}</AppNotice>}
      {packets.length > 0 && <section aria-label="Evidence packets">
        <h3 className="ai-app-subheading">Evidence packets</h3>
        <p className="ai-app-note">{`Authorized packet projection: ${PACKET_PROJECTION_EXTENSION}. Read the current question before answering.`}</p>
        <label htmlFor="ai-core-packet">Evidence packet</label>
        <select id="ai-core-packet" value={packetId} disabled={busy || recoveryBlocked} onChange={(event): void => {
          const next = packets.filter((packet): boolean => packet.packetId === event.target.value)[0];
          setPacketId(next?.packetId ?? '');
          setResponse(next?.response ?? '');
          setDisposition(''); setAssertion(''); setSourceRefs('');
          const known = next?.knownAssumedUnknown as KnownAssumedUnknown | undefined;
          setCertainty(known !== undefined && KNOWN_ASSUMED_UNKNOWN.indexOf(known) >= 0 ? known : 'UNKNOWN');
        }}>
          <option value="">Choose a packet</option>
          {packets.map((packet): React.ReactElement => <option key={packet.packetId} value={packet.packetId}>{`${packet.packetType} — ${packet.packetId} — ${packet.status}`}</option>)}
        </select>
        {selectedPacket !== undefined && <React.Fragment>
          <ul>{selectedPacket.questions.map((question, index): React.ReactElement => <li key={index}>{question}</li>)}</ul>
          <p>{`Version ${selectedPacket.currentVersion}. ${selectedPacket.required ? 'Required' : 'Optional'}. Role: ${selectedPacket.assignedRole ?? 'unbound'}; person: ${selectedPacket.assignedPerson ?? 'unbound'}; due: ${selectedPacket.dueDate ?? 'not set'}.`}</p>
          <label htmlFor="ai-core-response">Evidence response</label>
          <textarea id="ai-core-response" value={response} disabled={busy || recoveryBlocked} onChange={(event): void => setResponse(event.target.value)} />
          <label htmlFor="ai-core-certainty">Certainty</label>
          <select id="ai-core-certainty" value={certainty} disabled={busy || recoveryBlocked} onChange={(event): void => setCertainty(event.target.value as KnownAssumedUnknown)}>
            {KNOWN_ASSUMED_UNKNOWN.map((known): React.ReactElement => <option key={known} value={known}>{known}</option>)}
          </select>
        </React.Fragment>}
        <button type="button" disabled={busy || recoveryBlocked || work === undefined || selectedPacket === undefined || response.trim() === ''} onClick={(): void => run(async (): Promise<void> => {
          if (work !== undefined && selectedPacket !== undefined) {
            await apply(await coreWork.submitEvidence(session, { workId: work.workId, evidencePacketId: selectedPacket.packetId, response: response.trim(), knownAssumedUnknown: certainty }));
          }
        })}>Save evidence response</button>
        {selectedPacket !== undefined && (mayValidate ? coreWork.validateEvidence === undefined ?
          <AppNotice>Human validation is unavailable in this service. A bound server-authorized validation operation is required.</AppNotice> :
          <fieldset disabled={busy || recoveryBlocked}>
            <legend>Human evidence validation</legend>
            <p>The server authorizes each validation against the signed-in reviewer and the current packet version. This form does not grant a role or bypass that check.</p>
            <label htmlFor="ai-core-disposition">Validation disposition</label>
            <select id="ai-core-disposition" value={disposition} onChange={(event): void => setDisposition(event.target.value as typeof disposition)}>
              <option value="">Choose a disposition</option>
              <option value="VALIDATED">Validated</option>
              <option value="REJECTED">Rejected</option>
              <option value="NOT_APPLICABLE">Not applicable</option>
            </select>
            <label htmlFor="ai-core-assertion">Human validation assertion</label>
            <textarea id="ai-core-assertion" value={assertion} maxLength={8000} onChange={(event): void => setAssertion(event.target.value)} />
            <label htmlFor="ai-core-source-refs">Supporting source references (one per line)</label>
            <textarea id="ai-core-source-refs" value={sourceRefs} onChange={(event): void => setSourceRefs(event.target.value)} />
            <button type="button" disabled={busy || recoveryBlocked || work === undefined || disposition === '' || assertion.trim().length < 10 || references.length === 0} onClick={(): void => {
              if (!mayValidate || coreWork.validateEvidence === undefined || work === undefined || disposition === '' || assertion.trim().length < 10 || references.length === 0) { return; }
              run(async (): Promise<void> => { await apply(await coreWork.validateEvidence!(session, { workId: work.workId, evidencePacketId: selectedPacket.packetId, disposition, assertion: assertion.trim(), sourceRefs: references })); });
            }}>Record human validation</button>
          </fieldset> : <AppNotice>Human validation requires a resolved Design authority role and server authorization. No reviewer role can be assumed here.</AppNotice>)}
      </section>}
    </div>
  );
}
