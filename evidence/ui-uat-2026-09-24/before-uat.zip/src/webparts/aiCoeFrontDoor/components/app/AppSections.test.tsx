import * as React from 'react';
import { act, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithFrontDoor } from '../../../../testing/renderWithFrontDoor';
import { AppShell } from './AppShell';

async function shell(): Promise<ReturnType<typeof renderWithFrontDoor>> {
  const result = renderWithFrontDoor(<AppShell settings={{ view: 'app', layout: 'narrow', pages: {} }} />);
  await act(async () => undefined);
  return result;
}

describe('same-app measurement and teaching entry', () => {
  it('opens and closes the guidance with keyboard controls in the narrow layout', async () => {
    const view = await shell();
    const user = userEvent.setup();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    const button = view.getByRole('button', { name: 'Getting started: safe task and review' });
    button.focus();
    await user.keyboard('{Enter}');
    expect(button).toHaveAttribute('aria-expanded', 'true');
    expect(view.getByRole('region', { name: 'Getting started: safe task and review' })).toBeInTheDocument();
    await user.keyboard(' ');
    expect(button).toHaveAttribute('aria-expanded', 'false');
    expect(view.queryByRole('region', { name: 'Getting started: safe task and review' })).toBeNull();
    expect(view.container.querySelector('.ai-view--narrow')).not.toBeNull();
  });

  it('opens source, role, stop and recovery quick-start guidance from Engineering without a private source link', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Engineering' }));
    const guide = view.getByRole('button', { name: 'Getting started: safe task and review' });
    expect(guide).toHaveAttribute('aria-expanded', 'false');
    fireEvent.click(guide);
    expect(guide).toHaveAttribute('aria-expanded', 'true');
    const region = view.getByRole('region', { name: 'Getting started: safe task and review' });
    expect(region).toHaveTextContent('permitted sources');
    expect(region).toHaveTextContent('Reviewer');
    expect(region).toHaveTextContent('Champion');
    expect(region).toHaveTextContent('reconcile');
    expect(region).toHaveTextContent('not live acceptance');
    expect(region.querySelector('a[href^="http"]')).toBeNull();
    fireEvent.click(view.getByRole('button', { name: /Get help or training/ }));
    await waitFor(() => expect(view.container.querySelector('.ai-app-starters')).toBeNull());
    expect(view.governance.submissions).toHaveLength(0);
  });

  it('connects Improvement guidance to the existing outcome form, not another tracker', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    fireEvent.click(view.getByRole('button', { name: 'Getting started: safe task and review' }));
    expect(view.getByText(/No automatic policy change/)).toBeInTheDocument();
    fireEvent.click(view.getByRole('button', { name: /Record a task outcome/ }));
    await waitFor(() => expect(view.getByText('What kind of task was it?')).toBeInTheDocument());
    expect(view.governance.submissions).toHaveLength(0);
  });

  it('makes manual commissioning and proposal/retest instructions reachable without publishing or claiming approval', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    fireEvent.click(view.getByRole('button', { name: 'Operator commissioning: manual review and publication' }));
    const region = view.getByRole('region', { name: 'Operator commissioning: manual review and publication' });
    expect(region).toHaveTextContent('aggregate-workflow-outcomes.cjs');
    expect(region).toHaveTextContent('No approved business method or dataset is supplied');
    expect(region).toHaveTextContent('unknown');
    expect(region).toHaveTextContent('read back');
    expect(view.getByText(/retest receipt/)).toBeInTheDocument();
    fireEvent.click(view.getByRole('button', { name: /Share feedback/ }));
    await waitFor(() => expect(view.container.querySelector('.ai-app-starters')).toBeNull());
    expect(view.governance.submissions).toHaveLength(0);
  });
});
