import * as React from 'react';
import * as fs from 'fs';
import * as path from 'path';
import { act, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithFrontDoor } from '../../../../testing/renderWithFrontDoor';
import { AppShell } from './AppShell';

async function shell(): Promise<ReturnType<typeof renderWithFrontDoor>> {
  const result = renderWithFrontDoor(<AppShell settings={{ view: 'app', layout: 'narrow', pages: {} }} />);
  await act(async () => undefined);
  return result;
}

describe('same-app measurement and teaching entry', () => {
  it('restores only the team registration form to its previous centered workflow width', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    expect(view.container.querySelector('.ai-workflow-shell')).toBeNull();
    fireEvent.click(view.getByRole('button', { name: /^Register team AI use/ }));
    await waitFor(() => expect(view.container.querySelector('.overture-card')).not.toBeNull());
    const card = view.container.querySelector('.overture-card');
    expect(card?.closest('.ai-workflow-shell')).not.toBeNull();
    expect(view.getByRole('heading', { name: 'Improvement', exact: true }).closest('.ai-workflow-shell')).toBeNull();
    expect(view.getByRole('tablist').closest('.ai-workflow-shell')).toBeNull();
    const styles = fs.readFileSync(path.join(process.cwd(), 'src/webparts/aiCoeFrontDoor/styles/frontDoor.global.scss'), 'utf8');
    expect(styles).toMatch(/\.ai-workflow-shell\s*\{[^}]*margin:\s*0 auto;[^}]*max-width:\s*48rem;/);
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    expect(view.container.querySelector('.ai-workflow-shell')).toBeNull();
    fireEvent.click(view.getByRole('button', { name: /^Record a task outcome/ }));
    await waitFor(() => expect(view.getByText('What kind of task was it?')).toBeInTheDocument());
    expect(view.container.querySelector('.ai-workflow-shell')).toBeNull();
  });


  it('pads the Improvement starter row above its cards without narrowing the overview', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    const row = view.getByRole('button', { name: /^Register team AI use/ }).closest('ul');
    expect(row).toHaveClass('ai-app-starters--spaced');
    expect(row?.closest('.ai-workflow-shell')).toBeNull();
    const styles = fs.readFileSync(path.join(process.cwd(), 'src/webparts/aiCoeFrontDoor/styles/appShell.global.scss'), 'utf8');
    expect(styles).toMatch(/\.ai-app-starters--spaced\s*\{[^}]*padding-top:\s*24px;/);
  });


  it('adds top padding to the Cases explanation row, not inside its cards', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Cases' }));
    const row = view.getByRole('heading', { name: 'What happens to a request' }).closest('.ai-app-split');
    expect(row).toHaveClass('ai-app-cases-explanation');
    expect(row).toContainElement(view.getByRole('heading', { name: 'Truth controls' }));
    const styles = fs.readFileSync(path.join(process.cwd(), 'src/webparts/aiCoeFrontDoor/styles/appShell.global.scss'), 'utf8');
    expect(styles).toMatch(/\.ai-app-cases-explanation\s*\{\s*padding-top:\s*24px;/);
  });

  it.each(['wide', 'narrow'] as const)('pads the Engineering starter region vertically in the %s layout without changing the cards', async layout => {
    const view = renderWithFrontDoor(<AppShell settings={{ view: 'app', layout, pages: {} }} />);
    await act(async () => undefined);
    fireEvent.click(view.getByRole('tab', { name: 'Engineering' }));
    const starters = view.container.querySelector('.ai-app-starters--engineering');
    expect(starters).not.toBeNull();
    expect(starters?.querySelectorAll('.ai-app-starter-button')).toHaveLength(3);
    expect(Array.from(starters?.querySelectorAll('.ai-app-starter-title') ?? []).map(node => node.textContent)).toEqual([
      'Explore an AI idea', 'Check a tool or task', 'Get help or training'
    ]);
    const styles = fs.readFileSync(path.join(process.cwd(), 'src/webparts/aiCoeFrontDoor/styles/appShell.global.scss'), 'utf8');
    expect(styles).toMatch(/\.ai-app-starters--engineering\s*\{\s*padding-block:\s*24px;\s*\}/);
    expect(styles).toMatch(/\.ai-view--app\.ai-view--narrow\s*\{[^}]*\.ai-app-starters,[^}]*grid-template-columns:\s*minmax\(0, 1fr\)/);
    expect(styles).toMatch(/@media \(max-width: 720px\)\s*\{[^}]*\.ai-app-starters,[^}]*grid-template-columns:\s*minmax\(0, 1fr\)/);
    fireEvent.click(view.getByRole('button', { name: /Check a tool or task/ }));
    await waitFor(() => expect(view.container.querySelector('.ai-app-starters')).toBeNull());
    expect(view.governance.submissions).toHaveLength(0);
  });

  it('opens and closes the guidance with keyboard controls in the narrow layout', async () => {
    const view = await shell();
    const user = userEvent.setup();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    const button = view.getByRole('button', { name: 'Getting started: safe task and review' });
    button.focus();
    await user.keyboard('{Enter}');
    expect(button).toHaveAttribute('aria-expanded', 'true');
    expect(view.getByRole('region', { name: 'Getting started: safe task and review' })).toBeInTheDocument();
    await user.keyboard(' ');
    expect(button).toHaveAttribute('aria-expanded', 'false');
    expect(view.queryByRole('region', { name: 'Getting started: safe task and review' })).toBeNull();
    expect(view.container.querySelector('.ai-view--narrow')).not.toBeNull();
  });

  it('opens source, role, stop and recovery quick-start guidance from Engineering without a private source link', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Engineering' }));
    const guide = view.getByRole('button', { name: 'Getting started: safe task and review' });
    expect(guide).toHaveAttribute('aria-expanded', 'false');
    fireEvent.click(guide);
    expect(guide).toHaveAttribute('aria-expanded', 'true');
    const region = view.getByRole('region', { name: 'Getting started: safe task and review' });
    expect(region).toHaveTextContent('permitted sources');
    expect(region).toHaveTextContent('Reviewer');
    expect(region).toHaveTextContent('Champion');
    expect(region).toHaveTextContent('reconcile');
    expect(region).toHaveTextContent('not live acceptance');
    expect(region.querySelector('a[href^="http"]')).toBeNull();
    fireEvent.click(view.getByRole('button', { name: /Get help or training/ }));
    await waitFor(() => expect(view.container.querySelector('.ai-app-starters')).toBeNull());
    expect(view.governance.submissions).toHaveLength(0);
  });

  it('connects Improvement guidance to the existing outcome form, not another tracker', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    fireEvent.click(view.getByRole('button', { name: 'Getting started: safe task and review' }));
    expect(view.getByText(/No automatic policy change/)).toBeInTheDocument();
    fireEvent.click(view.getByRole('button', { name: /Record a task outcome/ }));
    await waitFor(() => expect(view.getByText('What kind of task was it?')).toBeInTheDocument());
    expect(view.governance.submissions).toHaveLength(0);
  });

  it('keeps Improvement proposal/retest guidance without the misplaced operator commissioning control', async () => {
    const view = await shell();
    fireEvent.click(view.getByRole('tab', { name: 'Improvement' }));
    expect(view.queryByRole('button', { name: /Operator commissioning/ })).toBeNull();
    expect(view.queryByRole('region', { name: /Operator commissioning/ })).toBeNull();
    expect(view.container.textContent).not.toContain('aggregate-workflow-outcomes.cjs');
    expect(view.getByText(/No automatic policy change/)).toBeInTheDocument();
    expect(view.getByText(/retest receipt/)).toBeInTheDocument();
    fireEvent.click(view.getByRole('button', { name: /Share feedback/ }));
    await waitFor(() => expect(view.container.querySelector('.ai-app-starters')).toBeNull());
    expect(view.governance.submissions).toHaveLength(0);
  });
});
